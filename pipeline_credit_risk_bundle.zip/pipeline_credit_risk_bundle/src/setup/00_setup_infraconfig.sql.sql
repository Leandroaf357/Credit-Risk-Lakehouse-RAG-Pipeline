-- Databricks notebook source
-- COMMAND ----------
-- DBTITLE 1,1. Catalog Creation
CREATE CATALOG IF NOT EXISTS credit_risk;
USE CATALOG credit_risk;

-- COMMAND ----------
-- DBTITLE 2,2. Schema / Layer Isolation
CREATE SCHEMA IF NOT EXISTS bronze;
CREATE SCHEMA IF NOT EXISTS silver;
CREATE SCHEMA IF NOT EXISTS gold;

-- COMMAND ----------
-- DBTITLE 3,3. Managed Volume Creation (Landing Zone)
CREATE VOLUME IF NOT EXISTS credit_risk.bronze.landing_zone;
COMMENT ON VOLUME credit_risk.bronze.landing_zone IS 'Landing Zone for raw Credit Risk files';

-- COMMAND ----------
-- DBTITLE 4,4. Centralized Pipeline Telemetry Log Table
CREATE TABLE IF NOT EXISTS credit_risk.bronze.log_pipeline_execution (
    execution_id STRING,
    pipeline_name STRING,
    target_table STRING,
    rows_processed LONG,
    status STRING,
    error_message STRING,
    execution_timestamp TIMESTAMP
)
USING DELTA;

-- COMMAND ----------
-- DBTITLE 5,5. Gold Textual Layer for RAG (Vector Search)
CREATE TABLE IF NOT EXISTS credit_risk.gold.gold_credit_text_summary (
    chunk_text STRING,
    id_key STRING
)
USING DELTA
TBLPROPERTIES (delta.enableChangeDataFeed = true);
COMMENT ON TABLE credit_risk.gold.gold_credit_text_summary IS 'Textual representation of loan summaries optimized for RAG and Vector Search';