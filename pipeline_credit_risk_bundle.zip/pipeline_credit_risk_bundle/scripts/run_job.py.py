# Databricks notebook source
# MAGIC %pip install databricks-sdk --upgrade

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# Databricks notebook source
# %pip install databricks-sdk --upgrade
from databricks.sdk import WorkspaceClient

def executar_job_por_nome(nome_job):
    w = WorkspaceClient()
    print(f"🔍 Buscando o job: '{nome_job}'...")
    
    job_id = None
    for job in w.jobs.list():
        if job.settings.name == nome_job:
            job_id = job.job_id
            break
            
    if not job_id:
        print(f"❌ Job '{nome_job}' não encontrado. Lembre-se de rodar 'databricks bundle deploy -t development' no web terminal antes.")
        return
        
    print(f"✅ Job encontrado (ID: {job_id}). Iniciando execução...")
    run = w.jobs.run_now(job_id=job_id).result()
    
    if run.state.result_state.value == 'SUCCESS':
        print(f"🚀 Sucesso! O pipeline '{nome_job}' foi executado perfeitamente.")
        print(f"🔗 URL da Execução: {run.run_page_url}")
    else:
        print(f"⚠️ Atenção: O pipeline finalizou com status: {run.state.result_state.value}")
        print(f"🔗 Veja os logs detalhados: {run.run_page_url}")

if __name__ == "__main__":
    executar_job_por_nome("Credit Risk Medallion Pipeline")